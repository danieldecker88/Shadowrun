#include "genesis.h"
#include "utils.h"
#include "interr.h"

void init_interr(){
}

void poll_interr(){
}
